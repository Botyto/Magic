﻿using UnityEngine;

/// <summary>
/// A phyisically manifested spell.
/// This class doesn't add any additional logic to the spell cycle.
/// Instead it provides a common interface for all individual spells that are physically manifested.
/// </summary>
[RequireComponent(typeof(EnergyController))]
[RequireComponent(typeof(EnergyManifestation))]
public abstract class ManifestedSpellBase : SpellBase
{
    #region Members

    /// <summary>
    /// Own energy controller
    /// </summary>
    public EnergyController controller { get; private set; }

    /// <summary>
    /// Own energy cost calculator
    /// </summary>
    public IEnergyCost cost { get { return controller.cost; } }

    /// <summary>
    /// Own energy manifestation
    /// </summary>
    public EnergyManifestation manifestation { get; private set; }

    /// <summary>
    /// Own rigidbody
    /// </summary>
    public Rigidbody rigidBody { get { return manifestation.rigidBody; } }

    #endregion
    
    #region Manifested energy interface

    /// <summary>
    /// Called when this spell enters collision with another manifestation
    /// </summary>
    protected virtual void OnEnergyCollisionEnter(EnergyManifestation other)
    { }

    /// <summary>
    /// Called when this spell exits collision with another manifestation
    /// </summary>
    protected virtual void OnEnergyCollisionExit(EnergyManifestation other)
    { }

    #endregion

    #region Utility functions

    /// <summary>
    /// Check if a target is reachable (thus energy can be controlled there)
    /// </summary>
    public bool IsWithinRange<T>(T target) where T : MonoBehaviour
    {
        return controller.IsWithinRange(target);
    }

    /// <summary>
    /// Check if a point is reachable (thus energy can be controlled there)
    /// </summary>
    public bool IsWithinRange(Vector3 absolutePosition)
    {
        return controller.IsWithinRange(absolutePosition);
    }

    /// <summary>
    /// Unified way of strictly checking if an energy operation/action has succeeded
    /// </summary>
    protected bool TryStrict(EnergyActionResult actionResult)
    {
        return EnergyController.TryStrict(actionResult);
    }

    /// <summary>
    /// Unified way of checking if an energy operation/action has succeeded (redundant actions are accepted)
    /// </summary>
    protected bool Try(EnergyActionResult actionResult)
    {
        return EnergyController.Try(actionResult);
    }

    /// <summary>
    /// Manually cancel (interrupt/finish) the spell
    /// </summary>
    public override void Cancel()
    {
        manifestation.Smash();
        base.Cancel();
    }

    #endregion

    #region Raw controller functions

    /// <summary>
    /// Remotely charges an energy manifestation (cheaper than manifesting & merging).
    /// </summary>
    public EnergyActionResult Charge(EnergyManifestation other, int amount)
    {
        return controller.Charge(other, amount);
    }

    /// <summary>
    /// Remotely discharges an energy manifestation.
    /// </summary>
    public EnergyActionResult Discharge(EnergyManifestation other, int amount)
    {
        return controller.Discharge(other, amount);
    }

    /// <summary>
    /// Marge self with another manifestation
    /// </summary>
    public EnergyActionResult MergeSelf(EnergyManifestation other)
    {
        return controller.Merge(manifestation, other);
    }

    /// <summary>
    /// Separate self into two manifestations
    /// </summary>
    public EnergyActionResult SeparateSelf(int amount, Vector3 force, out EnergyManifestation separatedEnergy)
    {
        return controller.Separate(manifestation, amount, force, out separatedEnergy);
    }

    /// <summary>
    /// Sacrifice a manifestation to summon an object in it's place
    /// </summary>
    public EnergyActionResult SummonSelf(SummonRecipe recipe, out GameObject summonedObj)
    {
        return controller.Summon(manifestation, recipe, out summonedObj);
    }

    /// <summary>
    /// Change own manifestation element
    /// </summary>
    public EnergyActionResult ChangeElementSelf(Energy.Element newElement)
    {
        return controller.ChangeElement(manifestation, newElement);
    }

    /// <summary>
    /// Change own manifestation shape
    /// </summary>
    public EnergyActionResult ChangeShapeSelf(Energy.Shape newShape)
    {
        return controller.ChangeShape(manifestation, newShape);
    }

    /// <summary>
    /// Deform own manifestation
    /// </summary>
    public EnergyActionResult DeformSelf(Vector3 stress)
    {
        return controller.Deform(manifestation, stress);
    }

    /// <summary>
    /// Apply force on self (at center of mass). The force vector is relative to own transform.
    /// </summary>
    public EnergyActionResult ApplyForceRelativeSelf(Vector3 relativeForce, ForceMode mode)
    {
        return controller.ApplyForceRelative(manifestation, relativeForce, mode);
    }

    /// <summary>
    /// Apply force on self (at center of mass).
    /// </summary>
    public EnergyActionResult ApplyForceSelf(Vector3 force, ForceMode mode)
    {
        return controller.ApplyForce(manifestation, force, mode);
    }

    /// <summary>
    /// Apply torque on self (at center of mass)
    /// </summary>
    public EnergyActionResult ApplyTorqueSelf(Vector3 torque, ForceMode mode)
    {
        return controller.ApplyTorque(manifestation, torque, mode);
    }

    /// <summary>
    /// Apply an aura to some object
    /// </summary>
    public EnergyActionResult ApplyAura<T>(GameObject target, int extractedEnergy, out T aura) where T : AuraBase
    {
        return controller.ApplyAura(manifestation, target, extractedEnergy, out aura);
    }

    /// <summary>
    /// Substitute two objects
    /// </summary>
    public EnergyActionResult Substitute(GameObject first, GameObject second)
    {
        return controller.Substitute(manifestation, first, second);
    }

    /// <summary>
    /// Probe spatial point for manifested energy
    /// </summary>
    public EnergyActionResult ProbePoint(Vector3 relatitvePosition, out EnergyController.EnergyProbeResult probeResult)
    {
        return controller.ProbePoint(relatitvePosition, out probeResult);
    }

    #endregion

    #region Specialized interface

    /// <summary>
    /// Apply a force on self, such that it will keep the manifestation from falling down.
    /// </summary>
    public EnergyActionResult CounterFalling()
    {
        if (rigidBody.velocity.y >= 0.0f)
        {
            return EnergyActionResult.RedundantAction;
        }

        return ApplyForceSelf(Vector3.up * rigidBody.velocity.y, ForceMode.Force); //TODO check if this is correct
    }

    /// <summary>
    /// Appply a force on self, such that it will make the manifestation seem as if it were not affected by gravity.
    /// </summary>
    public EnergyActionResult CounterGravity()
    {
        if (!rigidBody.useGravity)
        {
            return EnergyActionResult.RedundantAction;
        }

        return ApplyForceSelf(-Physics.gravity, ForceMode.Acceleration);
    }

    #endregion

    #region Unity internals

    protected override void Awake()
    {
        base.Awake();
        controller = GetComponent<EnergyController>();
        manifestation = GetComponent<EnergyManifestation>();
        //manifestation.energyCollisionEvent += HandleCollision;
    }

    private void HandleCollision(EnergyManifestation _this, EnergyManifestation other, EnergyManifestation.CollisionEventType ev)
    {
        if (ev == EnergyManifestation.CollisionEventType.Enter)
        {
            OnEnergyCollisionEnter(other);
        }
        else //if exit collision event
        {
            OnEnergyCollisionExit(other);
        }
    }

    #endregion
}
