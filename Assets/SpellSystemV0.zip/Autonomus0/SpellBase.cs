﻿using UnityEngine;

/// <summary>
/// Base class for implementing spell logic.
/// This is one way to interact with and control spells (See SpellDefinitionBase).
/// This one is designed to work internally on a spell manifestation (locally) and is not tied to a Wizard (caster),
/// but is instead independant of all other spell components.
/// </summary>
public abstract class SpellBase : EnergyUser
{
    #region Spell interface

    /// <summary>
    /// Target this spell has - TODO implement multiple targets (see SpellExecutionContext)
    /// </summary>
    public GameObject target;

    /// <summary>
    /// Called when the spell has began casting
    /// </summary>
    public abstract void OnBegin();

    /// <summary>
    /// Called frequently (once per physical tick)
    /// </summary>
    public virtual void OnUpdate(float dt) { }

    /// <summary>
    /// Called if the spell has been canceled manually
    /// </summary>
    public virtual void OnCancel() { }

    /// <summary>
    /// Called if the spell's target has been lost
    /// </summary>
    public virtual void OnTargetLost() { }

    /// <summary>
    /// Called whenever the spell finishes (cancel, natural finish, energy depleted, collision, ...)
    /// </summary>
    public virtual void OnEnd() { }

    /// <summary>
    /// Manually cancel (interrupt/finish) the spell
    /// </summary>
    public virtual void Cancel()
    {
        OnCancel();
        Util.Destroy(gameObject, "canceled");
    }

    #endregion

    #region Unity internals

    /// <summary>
    /// If the spell had a valid target the previous frame
    /// </summary>
    private bool m_HadTarget;

    protected virtual void Start() //TODO does this need to be OnEnable() (changed it because target cannot be set in OnBegin()) ? Maybe add OnInit() ?
    {
        OnBegin();
        m_HadTarget = target != null;
    }

    protected virtual void FixedUpdate()
    {
        if (target == null && m_HadTarget)
        {
            OnTargetLost();
        }

        OnUpdate(Time.fixedDeltaTime);
        m_HadTarget = target != null;
    }

    protected virtual void OnDestroy()
    {
        OnEnd();
    }

    #endregion
}
