﻿using System.Collections;

/// <summary>
/// An empty spell definition. Does nothing and finishes almost instantly.
/// This class is useful for simple spells that do not implement most execution steps.
/// </summary>
public class EmptySpellDefinition : SpellDefinition
{
    public EmptySpellDefinition(string spellId)
        : base(spellId)
    { }

    public override bool IsCastingFinished(SpellExecutionContext ctx)
    {
        return true;
    }

    public override bool IsExecutionFinished(SpellExecutionContext ctx)
    {
        return true;
    }

    public override IEnumerator OnCast(SpellExecutionContext ctx, float dt)
    {
        yield return null;
    }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        yield return null;
    }

    public override IEnumerator OnCastFinish(SpellExecutionContext ctx)
    {
        yield return null;
    }

    public override IEnumerator OnExecute(SpellExecutionContext ctx, float dt)
    {
        yield return null;
    }

    public override IEnumerator OnExecutionBegin(SpellExecutionContext ctx)
    {
        yield return null;
    }

    public override IEnumerator OnExecutionFinish(SpellExecutionContext ctx)
    {
        yield return null;
    }
}
