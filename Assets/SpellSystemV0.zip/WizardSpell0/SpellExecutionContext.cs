﻿using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Context in which a spell is executed.
/// This is an object that provides a bridge (middle ground)
/// for two independant objects - the casting Wizard and the casted SpellDefinition.
/// An execution context is created for each spell execution and is destroyed after the execution has finished.
/// Contexts can be used for temporarily storing data between spell execution steps.
/// </summary>
[Serializable]
public class SpellExecutionContext
{
    /// <summary>
    /// Spell execution stage
    /// </summary>
    public enum Stage
    {
        Initializing,
        Casting,
        Executing,
        Finishing,
        Finished,
    }

    public SpellExecutionContext(Wizard_OLD wizard, SpellDefinitionBase spell)
    {
        this.wizard = wizard;
        controller = wizard.GetComponent<EnergyController>();
        this.spell = spell;
        focus = new List<EnergyManifestation>();
    }

    /// <summary>
    /// Current spell execution stage.
    /// </summary>
    public Stage stage;

    /// <summary>
    /// Casting Wizard.
    /// </summary>
    public Wizard_OLD wizard { get; private set; }

    /// <summary>
    /// The Wizards energy controller.
    /// </summary>
    public EnergyController controller { get; private set; }

    /// <summary>
    /// Definition of the executed spell.
    /// </summary>
    public SpellDefinitionBase spell { get; private set; }

    /// <summary>
    /// Coroutine handler associated with this spell execution.
    /// </summary>
    public Coroutine coroutine { get; private set; }

    /// <summary>
    /// List of manifestations for use by the spell.
    /// </summary>
    public List<EnergyManifestation> focus;

    /// <summary>
    /// Target this spell has - TODO implement multiple targets (see SpellBase)
    /// </summary>
    public GameObject target;
    
    public void SetCoroutine(Coroutine coroutine)
    {
        this.coroutine = coroutine;
    }
}
