﻿using System;
using System.Collections;

/// <summary>
/// Base class for all spells.
/// This is one way to interact with and control spells (See SpellBase).
/// This one is designed to work externally on a spell (globally) and is tied to a Wizard (caster).
/// This specific class is designed to display the most basic interface required for spell logic of this type (see SpellDefinition).
/// The order in which the methods will be called is the order in which they appear. For confirmation see Wizard.SpellCoroutine().
/// This class is instanciated only once and should not be confused and implemented as if and object would be created each time this spell is cast (see SpellExecutionContext).
/// </summary>
[Serializable]
public abstract class SpellDefinitionBase
{
    public SpellDefinitionBase(string spellId)
    {
        id = spellId;
    }

    /// <summary>
    /// Spell unique identifier name.
    /// </summary>
    public string id { get; private set; }

    //Step 1: Prerequisites
    public virtual bool CanBegin(SpellExecutionContext ctx) { return true; } //Note: ctx.coroutine cannot be used here!

    //Step 2: Initialization
    public virtual IEnumerator OnBegin(SpellExecutionContext ctx) { yield return null; }

    //Step 3: Casting
    public abstract IEnumerator OnCastBegin(SpellExecutionContext ctx);
    public abstract bool IsCastingFinished(SpellExecutionContext ctx);
    public abstract IEnumerator OnCast(SpellExecutionContext ctx, float dt);
    public abstract IEnumerator OnCastFinish(SpellExecutionContext ctx);
    public virtual IEnumerator OnCastInterrupted(SpellExecutionContext ctx) { yield return null; }

    //Step 4: Execution
    public abstract IEnumerator OnExecutionBegin(SpellExecutionContext ctx);
    public abstract bool IsExecutionFinished(SpellExecutionContext ctx);
    public abstract IEnumerator OnExecute(SpellExecutionContext ctx, float dt);
    public abstract IEnumerator OnExecutionFinish(SpellExecutionContext ctx);
    public virtual IEnumerator OnExecutionInterrupted(SpellExecutionContext ctx) { yield return null; }

    //Step 5: Finish
    public virtual IEnumerator OnFinish(SpellExecutionContext ctx) { yield return null; }
}
