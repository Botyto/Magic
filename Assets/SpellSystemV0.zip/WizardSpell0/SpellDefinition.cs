﻿using UnityEngine;

/// <summary>
/// An extension to SpellDefinitionBase.
/// This class does not implement any further logic on the actual spell execution,
/// but instead provides simplifed tools for interacting with and controlling spells.
/// </summary>
public abstract class SpellDefinition : SpellDefinitionBase
{
    public bool requireTarget = false;

    public SpellDefinition(string spellId)
        : base(spellId)
    { }

    /// <summary>
    /// Implement target requirement check
    /// </summary>
    public override bool CanBegin(SpellExecutionContext ctx)
    {
        //Note: ctx.coroutine cannot be used here!
        return !requireTarget || ctx.target != null;
    }

    /// <summary>
    /// If no target is provided to the context, but the spell requires one, this function will try to find it
    /// </summary>
    public virtual GameObject TryFindTarget(SpellExecutionContext ctx) { return null; } //Note: do not write in ctx.target here!

    /// <summary>
    /// Checks if a manifestation is still valid and can be operated on.
    /// </summary>
    public bool IsValid(EnergyManifestation manifestation)
    {
        return manifestation != null && manifestation.gameObject != null;
    }

    /// <summary>
    /// Checks if the target in the execution context is still valid.
    /// </summary>
    public bool HasTarget(SpellExecutionContext ctx)
    {
        return ctx.target != null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ctx"></param>
    public void CancelAllFocused(SpellExecutionContext ctx)
    {
        foreach (var manif in ctx.focus)
        {
            if (IsValid(manif))
            {
                var spell = manif.GetComponent<SpellBase>();
                if (spell != null)
                {
                    spell.Cancel();
                }
                else
                {
                    manif.Smash();
                }
            }
        }
    }

    /// <summary>
    /// Unified way of strictly checking if an energy operation/action has succeeded.
    /// </summary>
    public bool TryStrict(EnergyActionResult actionResult)
    {
        return EnergyController.TryStrict(actionResult);
    }

    /// <summary>
    /// Unified way of checking if an energy operation/action has succeeded (redundant actions are accepted).
    /// </summary>
    public bool Try(EnergyActionResult actionResult)
    {
        return EnergyController.Try(actionResult);
    }

    /// <summary>
    /// Attach a behavioural component to an energy manifestation.
    /// </summary>
    public T AttachBehaviour<T>(EnergyManifestation target) where T : MonoBehaviour
    {
        return target.gameObject.AddComponent<T>();
    }

    /// <summary>
    /// Attach a spell behavioural component to an energy manifestation.
    /// </summary>
    public T AttachSpellBehaviour<T>(EnergyManifestation target) where T : SpellBase
    {
        return target.gameObject.AddComponent<T>();
    }

    /// <summary>
    /// Attach a spell behavioural component to an energy manifestation.
    /// </summary>
    public T AttachSpellBehaviour<T>(EnergyManifestation target, GameObject spellTarget) where T : SpellBase
    {
        var behaviour = target.gameObject.AddComponent<T>();
        if (behaviour != null)
        {
            behaviour.target = spellTarget;
        }

        return behaviour;
    }

    /// <summary>
    /// Trigger a spell on the executing wizard.
    /// The new spell's target is the same as this spell.
    /// </summary>
    public bool TriggerWizardSpell(SpellExecutionContext ctx, string spell)
    {
        return TriggerWizardSpell(ctx, spell, ctx.target);
    }

    /// <summary>
    /// Trigger a spell on the executing wizard.
    /// </summary>
    public bool TriggerWizardSpell(SpellExecutionContext ctx, string spell, GameObject target)
    {
        return ctx.wizard.SpellCast(spell, target);
    }
}
