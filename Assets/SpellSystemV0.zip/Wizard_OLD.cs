﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EnergyController))]
public class Wizard_OLD : MonoBehaviour
{
    List<SpellDefinition> spells = new List<SpellDefinition>();
    Dictionary<string, SpellExecutionContext> currentSpells = new Dictionary<string, SpellExecutionContext>();

    public delegate void NewSpellAddedHandler(Wizard_OLD wizard, string spellId);
    public event NewSpellAddedHandler NewSpellAdded;

    public EnergyHolder holder { get { return GetComponent<EnergyHolder>(); } }

    public bool SpellAdd(SpellDefinition spell)
    {
        spells.Add(spell);

        if (NewSpellAdded != null)
        {
            NewSpellAdded(this, spell.id);
        }

        return true;
    }

    public void SpellRemove(string spell)
    {
        var idx = spells.FindIndex(s => s.id == spell);
        if (idx >= 0)
        {
            spell.Remove(idx);
        }
    }

    public bool HasSpell(string spell)
    {
        var idx = spells.FindIndex(s => s.id == spell);
        return idx >= 0;
    }

    public bool SpellCast(string spell, GameObject target)
    {
        //Check if spell is already running
        SpellExecutionContext oldCtx;
        if (currentSpells.TryGetValue(spell, out oldCtx))
        {
            if (oldCtx.stage == SpellExecutionContext.Stage.Finished)
            {
                currentSpells.Remove(spell);
            }
            else
            {
                //If it is already running - we cannot cast it twice
                //TODO implement logic for casting spells multiple times
                return false;
            }
        }

        var idx = spells.FindIndex(s => s.id == spell);
        if (idx >= 0)
        {
            //Find spell definition
            var spellDefinition = spells[idx];

            //Create context
            var ctx = new SpellExecutionContext(this, spells[idx]);

            if (spellDefinition.requireTarget && target == null)
            {
                ctx.target = spellDefinition.TryFindTarget(ctx);
            }
            else
            {
                ctx.target = target;
            }

            //Check prerequisits
            if (!spellDefinition.CanBegin(ctx))
            {
                return false;
            }

            //Trigger spell coroutine
            var coroutine = StartCoroutine("SpellCoroutine", ctx);
            ctx.SetCoroutine(coroutine);
            currentSpells.Add(spell, ctx);

            //Success
            return true;
        }
        else
        {
            return false;
        }
    }

    public void InterruptSpell(string spell)
    {
        SpellExecutionContext ctx;
        if (currentSpells.TryGetValue(spell, out ctx))
        {
            if (ctx.stage == SpellExecutionContext.Stage.Casting)
            {
                ctx.spell.OnCastInterrupted(ctx);
            }
            else if (ctx.stage == SpellExecutionContext.Stage.Executing)
            {
                ctx.spell.OnExecutionInterrupted(ctx);
            }

            StopCoroutine(ctx.coroutine);
            currentSpells.Remove(spell);
        }
    }

    /// <summary>
    /// Internal procedure implementing the spell execution cycle (run as coroutine)
    /// </summary>
    private IEnumerator SpellCoroutine(SpellExecutionContext ctx)
    {
        var spell = ctx.spell;

        //initialize
        ctx.stage = SpellExecutionContext.Stage.Initializing;
        yield return spell.OnBegin(ctx);

        //cast
        ctx.stage = SpellExecutionContext.Stage.Casting;
        yield return spell.OnCastBegin(ctx);
        while (!spell.IsCastingFinished(ctx))
        {
            yield return spell.OnCast(ctx, Time.deltaTime);
        }
        yield return spell.OnCastFinish(ctx);

        //execute
        ctx.stage = SpellExecutionContext.Stage.Executing;
        yield return spell.OnExecutionBegin(ctx);
        while (!spell.IsExecutionFinished(ctx))
        {
            yield return spell.OnExecute(ctx, Time.deltaTime);
        }
        yield return spell.OnExecutionFinish(ctx);

        //finish
        ctx.stage = SpellExecutionContext.Stage.Finishing;
        yield return spell.OnFinish(ctx);

        ctx.stage = SpellExecutionContext.Stage.Finished;
    }
}
