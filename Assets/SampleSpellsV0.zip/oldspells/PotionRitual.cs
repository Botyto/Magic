﻿using System.Collections;
using UnityEngine;

public class PotionRitual : EmptySpellDefinition
{
    public SummonRecipe recipe;

    public PotionRitual()
        : base("Potion Ritual")
    { }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        ctx.controller.ManifestEnergy(50, Vector3.forward * 15, out manif);
        var ritualLogic = AttachSpellBehaviour<RitualSpell>(manif);
        ritualLogic.recipe = recipe;
        yield return null;
        TriggerWizardSpell(ctx, "Ritual Charging", manif.gameObject);
        yield break;
    }
}
