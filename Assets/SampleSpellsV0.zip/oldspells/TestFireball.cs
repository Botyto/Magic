﻿using UnityEngine;

public class TestFireball : ManifestedSpellBase
{
    public bool smart;
    public Energy.Element element = Energy.Element.Ice;
    public float radius = 1.0f;
    private Vector3 center;

    protected override void OnEnergyCollisionEnter(EnergyManifestation other)
    {
        if (other.transform.position.x < transform.position.x)
        {
            MergeSelf(other);
            ApplyForceSelf(-Physics.gravity, ForceMode.Impulse);
        }
    }

    public override void OnBegin()
    {
        var forceDirection = target.transform.position - transform.position;

        center = transform.position + new Vector3(forceDirection.y, 0, -forceDirection.x).SetLength(radius);

        if (!Try(ChangeShapeSelf(Energy.Shape.Sphere)))
        {
            Cancel();
        }

        if (!Try(ChangeElementSelf(element)))
        {
            Cancel();
        }

        if (!Try(ApplyForceRelativeSelf(forceDirection.SetLength(rigidBody.mass * 10.0f), ForceMode.Impulse)))
        {
            Cancel();
        }

        ApplyTorqueSelf(Vector3.up * 5, ForceMode.Impulse);
    }

    public override void OnTargetLost()
    {
        Cancel();
    }

    public override void OnUpdate(float dt)
    {
        CounterFalling();

        if (target == null)
        {
            return;
        }

        //track target
        var targetPos = target.transform.position;
        
        //if far away
        var targetBody = target.GetComponent<Rigidbody>();
        if (smart && transform.position.SqrDistanceTo(targetPos) > targetBody.velocity.sqrMagnitude)
        {
            //look at target velocity
            targetPos += targetBody.velocity;

            //move center
            center += (targetPos - center).SetLength(0.1f);

            //calc force
            var forceVector = (center - transform.position).SetLength(rigidBody.mass);
            forceVector.y = 0;

            //apply force if we have enough energy left
            var forceCost = cost.ApplyForce(controller, manifestation, forceVector, ForceMode.Impulse);
            if (forceCost < GetEnergy() / 5)
            {
                ApplyForceSelf(forceVector, ForceMode.Impulse);
            }
        }
        else //if close enough
        {
            var forceVector = (targetPos - transform.position).SetLength(rigidBody.mass / 3);
            ApplyForceSelf(forceVector, ForceMode.Impulse);
        }
    }
}
