﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyOffDef : EmptySpellDefinition
{
    public FlyOffDef()
        : base("Fly Off")
    { }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(50, Vector3.down, out manif)))
        {
            yield break;
        }

        ctx.controller.ChangeShape(manif, Energy.Shape.Cube);
        ctx.controller.Deform(manif, new Vector3(0, 15, 0));
        ctx.focus.Add(manif);

        ctx.wizard.GetComponent<Rigidbody>().AddForce(Vector3.up*10, ForceMode.Impulse);

        yield return null;
    }

    public override IEnumerator OnCastFinish(SpellExecutionContext ctx)
    {
        ctx.controller.ChangeElement(ctx.focus[0], Energy.Element.Ice);
        ctx.controller.ApplyForce(ctx.focus[0], new Vector3(0, 15, 15), ForceMode.Impulse);
        yield return null;
    }

    public override bool IsExecutionFinished(SpellExecutionContext ctx)
    {
        return ctx.wizard.transform.position.y > 5.0f;
    }

    public override IEnumerator OnExecute(SpellExecutionContext ctx, float dt)
    {
        ctx.controller.Deform(ctx.focus[0], new Vector3(0, 15, 0));
        yield return null;
    }

    public override IEnumerator OnExecutionFinish(SpellExecutionContext ctx)
    {
        ctx.focus[0].Smash();
        yield break;
    }
}
