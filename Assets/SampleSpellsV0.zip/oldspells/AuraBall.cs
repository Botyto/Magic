﻿using System;
using System.Reflection;
using UnityEngine;

public class AuraBall : ManifestedSpellBase
{
    public Type auraType;

    public override void OnBegin()
    {
        //manifestation.unitCollisionEvent += CollideUnit;

        var forceDirection = target.transform.position - transform.position;
        var len = GetEnergy() * 3.0f / 4.0f;
        ApplyForceSelf(forceDirection.SetLength(len), ForceMode.Impulse);
    }

    public override void OnUpdate(float dt)
    {
        CounterGravity();
    }
    
    public void CollideUnit(EnergyManifestation manif, Unit unit, EnergyManifestation.CollisionEventType ev)
    {
        MethodInfo method = typeof(AuraBall).GetMethod("ApplyAura");
        MethodInfo generic = method.MakeGenericMethod(auraType);
        var args = new object[] { unit.gameObject, GetEnergy(), null };
        if (!Try((EnergyActionResult)generic.Invoke(this, args)))
        {
            print("auraball fail");
            Cancel();
        }
        else
        {
            DamageAura aura = args[2] as DamageAura;
            if (aura != null)
            {
                aura.damageElement = Energy.Element.Ice;
            }
        }
    }
}
