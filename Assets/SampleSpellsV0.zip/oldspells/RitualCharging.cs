﻿using System.Collections;

public class RitualCharging : EmptySpellDefinition
{
    public RitualCharging()
        : base("Ritual Charging")
    {
        requireTarget = true;
    }

    public override bool CanBegin(SpellExecutionContext ctx)
    {
        if (!base.CanBegin(ctx))
        {
            return false;
        }

        var targetManif = ctx.target.GetComponent<EnergyManifestation>();
        return targetManif != null && targetManif.element == Energy.Element.Ritual;
    }

    public override bool IsCastingFinished(SpellExecutionContext ctx)
    {
        return ctx.target == null;
    }

    public override IEnumerator OnCast(SpellExecutionContext ctx, float dt)
    {
        ctx.controller.Charge(ctx.target.GetComponent<EnergyManifestation>(), 1);
        yield return null;
    }

    public override IEnumerator OnCastFinish(SpellExecutionContext ctx)
    {
        yield break;
    }
}
