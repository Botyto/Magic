﻿public class FloatingSpell : ManifestedSpellBase
{
    public override void OnBegin() { }

    public override void OnUpdate(float dt)
    {
        CounterGravity();
    }
}
