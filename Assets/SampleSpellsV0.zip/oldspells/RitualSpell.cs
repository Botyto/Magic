﻿using UnityEngine;

public class RitualSpell : ManifestedSpellBase
{
    public SummonRecipe recipe;

    public override void OnBegin()
    {
        //Interesting visuals
        ChangeShapeSelf(Energy.Shape.Cube);
        ApplyTorqueSelf(Vector3.up, ForceMode.Impulse);

        ChangeElementSelf(Energy.Element.Ritual); //Seal self

        //Prepare caches
        previousEnergy = GetEnergy();
        lastCharge = Time.time;
    }
    
    float previousEnergy;
    float lastCharge;

    public override void OnUpdate(float dt)
    {
        var en = GetEnergy();
        if (en > previousEnergy)
        {
            if (en > recipe.requiredEnergy)
            {
                GameObject summonedObj;
                var result = SummonSelf(recipe, out summonedObj);
                if (result != EnergyActionResult.Success)
                {
                    return;
                }
                else if (result != EnergyActionResult.NotEnoughEnergy)
                {
                    Cancel();
                    return;
                }
            }

            previousEnergy = GetEnergy();
            lastCharge = Time.time;
        }

        //Decay after 1 second no charging
        if (Time.time - lastCharge > 1.0f)
        {
            Cancel();
            return;
        }
    }
}
