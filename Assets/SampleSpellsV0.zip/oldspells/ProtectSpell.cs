﻿using System.Collections;
using UnityEngine;

public class ProtectSpell : EmptySpellDefinition
{
    public int times = 1;

    public ProtectSpell(string spellId, int times)
        : base(spellId)
    {
        this.times = times;
    }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(2000, Vector3.zero, out manif)))
        {
            yield break;
        }

        //manif.energyCollisionEvent += HandleCollision;
        AttachSpellBehaviour<FloatingSpell>(manif);
        ctx.focus.Add(manif);

        yield return null;
    }

    public override bool IsExecutionFinished(SpellExecutionContext ctx)
    {
        return ctx.focus[0] == null || times <= 0;
    }
    
    public override IEnumerator OnExecutionFinish(SpellExecutionContext ctx)
    {
        CancelAllFocused(ctx);
        yield return null;
    }

    public void HandleCollision(EnergyManifestation manif, EnergyManifestation other, EnergyManifestation.CollisionEventType ev)
    {
        if (ev != EnergyManifestation.CollisionEventType.Enter)
        {
            return;
        }

        var manifUnit = manif.holder.ResolveOwner().GetComponent<Unit>();
        var otherUnit = other.holder.ResolveOwner().GetComponent<Unit>();
        if (manifUnit == null || otherUnit == null)
        {
            return;
        }

        if (manifUnit.IsFriendly(otherUnit))
        {
            return;
        }

        var manifCtrl = manif.holder.ResolveOwner().GetComponent<EnergyController>();
        EnergyManifestation defender;
        var dir = other.transform.position - manifUnit.transform.position;
        manifCtrl.ManifestEnergy(100, manifUnit.transform.InverseTransformDirection(dir).SetLength(2), Energy.Element.Ice, Energy.Shape.Cube, out defender);
        --times;
    }
}
