﻿using UnityEngine;

public class SubstituteFirst : FloatingSpell
{
    public override void OnBegin()
    {
        ChangeElementSelf(Energy.Element.Mana);
        ChangeShapeSelf(Energy.Shape.Sphere);

        var forceDirection = transform.position - target.transform.position;
        ApplyForceSelf(forceDirection.SetLength(5), ForceMode.Impulse);

        //manifestation.objectCollisionEvent += ObjCollisionEnter;
    }
    
    private void ObjCollisionEnter(EnergyManifestation _this, GameObject obj, EnergyManifestation.CollisionEventType ev)
    {
        if (!Try(Substitute(target, obj)))
        {
            Cancel();
        }
    }
}
