﻿using System.Collections;
using UnityEngine;

public class ChargedFireball : EmptySpellDefinition
{
    public int chargeSpeed = 10;
    public int targetEnergy = 150;
    public float force = 10.0f;

    public ChargedFireball(string spellId, int chargeSpeed = 10, int targetEnergy = 150)
        : base(spellId)
    {
        this.chargeSpeed = chargeSpeed;
        this.targetEnergy = targetEnergy;
        requireTarget = true;
    }

    public override GameObject TryFindTarget(SpellExecutionContext ctx)
    {
        var unit = ctx.wizard.GetComponent<Unit>();
        if (!unit)
        {
            var obj = Util.FindClosestObject<Unit>(ctx.wizard.transform.position);
            return obj != null ? obj.gameObject : null;
        }
        else
        {
            var obj = unit.FindClosestEnemy();
            return obj != null ? obj.gameObject : null;
        }
    }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(10, Vector3.forward * 3, Energy.Element.Fire, Energy.Shape.Sphere, out manif)))
        {
            CancelAllFocused(ctx);
            yield break;
        }

        ctx.focus.Add(manif);
        yield return null;
    }

    public override bool IsCastingFinished(SpellExecutionContext ctx)
    {
        return ctx.focus[0].GetEnergy() >= targetEnergy;
    }

    public override IEnumerator OnCast(SpellExecutionContext ctx, float dt)
    {
        if (!IsValid(ctx.focus[0]))
        {
            CancelAllFocused(ctx);
            yield break;
        }

        if (!Try(ctx.controller.Charge(ctx.focus[0], chargeSpeed)))
        {
            CancelAllFocused(ctx);
            yield break;
        }
        else
        {
            yield return null;
        }
    }

    public override IEnumerator OnCastFinish(SpellExecutionContext ctx)
    {
        var manif = ctx.focus[0];
        var forceDirection = ctx.target.transform.position - manif.transform.position;
        var len = force;
        ctx.controller.ApplyForce(manif, forceDirection.SetLength(len), ForceMode.Impulse);
        yield break;
    }
}
