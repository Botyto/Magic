﻿using System.Collections;
using UnityEngine;

public class SubstituteFirstDef : EmptySpellDefinition
{
    public SubstituteFirstDef()
        : base("Substitute First")
    {
        requireTarget = true;
    }

    public override GameObject TryFindTarget(SpellExecutionContext ctx)
    {
        return ctx.wizard.gameObject;
    }

    public override IEnumerator OnBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(100, Vector3.forward*3, out manif)))
        {
            yield break;
        }

        AttachSpellBehaviour<SubstituteFirst>(manif, ctx.target);

        yield break;
    }
}
