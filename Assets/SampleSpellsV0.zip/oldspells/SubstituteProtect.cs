﻿using System.Collections;
using UnityEngine;

public class SubstituteProtect : EmptySpellDefinition
{
    public SubstituteProtect()
        : base("Substitute Protect")
    { }

    public override IEnumerator OnCastBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(5000, Vector3.zero, out manif)))
        {
            yield break;
        }

        //manif.energyCollisionEvent += HandleCollision;
        AttachSpellBehaviour<FloatingSpell>(manif);
        ctx.focus.Add(manif);

        yield return null;
    }

    public override bool IsExecutionFinished(SpellExecutionContext ctx)
    {
        return ctx.focus[0] == null;
    }

    public override IEnumerator OnExecutionFinish(SpellExecutionContext ctx)
    {
        CancelAllFocused(ctx);
        yield return null;
    }

    public void HandleCollision(EnergyManifestation manif, EnergyManifestation other, EnergyManifestation.CollisionEventType ev)
    {
        if (ev != EnergyManifestation.CollisionEventType.Enter)
        {
            return;
        }

        var manifUnit = manif.holder.ResolveOwner().GetComponent<Unit>();
        var otherUnit = other.holder.ResolveOwner().GetComponent<Unit>();
        if (manifUnit == null || otherUnit == null)
        {
            return;
        }

        if (manifUnit.IsFriendly(otherUnit))
        {
            return;
        }

        var manifWiz = manif.holder.ResolveOwner().GetComponent<Wizard_OLD>();
        manifWiz.SpellCast("Substitute First", manifWiz.gameObject);

        manif.Smash();
    }
}
