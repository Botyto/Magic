﻿using System.Collections;
using UnityEngine;

public class ParticlesTestSpell : EmptySpellDefinition
{
    public Energy.Element element = Energy.Element.Mana;

    public ParticlesTestSpell(Energy.Element element)
        : base(element.ToString() + "ParticlesTest")
    {
        this.element = element;
    }

    public override IEnumerator OnBegin(SpellExecutionContext ctx)
    {
        EnergyManifestation manif;
        if (!Try(ctx.controller.ManifestEnergy(150, Vector3.forward * 3, out manif)))
        {
            yield break;
        }

        ctx.focus.Add(manif);

        ctx.controller.ChangeShape(manif, Energy.Shape.Cube);
        ctx.controller.ChangeElement(manif, element);
        ctx.controller.ApplyForceRelative(manif, Vector3.forward, ForceMode.Impulse);

        if (manif.rigidBody.useGravity)
        {
            AttachBehaviour<FloatingSpell>(manif);
        }

        yield return null;
    }

    public override bool IsExecutionFinished(SpellExecutionContext ctx)
    {
        return ctx.focus[0] == null;
    }

    public override IEnumerator OnExecute(SpellExecutionContext ctx, float dt)
    {
        var manif = ctx.focus[0];
        if (manif.transform.position.DistanceTo(ctx.wizard.transform.position) > ctx.controller.controlRange/2.0f)
        {
            manif.Smash();
        }

        yield return null;
    }
}
