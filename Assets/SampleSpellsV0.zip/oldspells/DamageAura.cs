﻿public class DamageAura : AuraBase
{
    public Energy.Element damageElement;

    protected override void OnApply()
    {
        interval = 1.0f;
    }

    protected override void Activate(float dt)
    {
        InflictDamage((int)(dt * 10), damageElement);
    }
}
