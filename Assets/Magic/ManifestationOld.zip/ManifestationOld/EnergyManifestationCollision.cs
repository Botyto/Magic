﻿using System.Collections.Generic;
using UnityEngine;

public partial class EnergyManifestation
{
    #region Members

    /// <summary>
    /// Event type for collision events (see collision related events in this class)
    /// </summary>
    public enum CollisionEventType { Enter, Exit }

    /// <summary>
    /// Cached collider
    /// </summary>
    [SerializeField]
    private Collider m_Collider = null;

    /// <summary>
    /// Set of all objects currently colliding with the manifestation
    /// </summary>
    [SerializeField]
    private List<GameObject> m_Collided = new List<GameObject>();

    #endregion

    #region Public events

    public SpellObjectCollisionEvent objectCollisionEvent = new SpellObjectCollisionEvent();
    public SpellEnergyCollisionEvent energyCollisionEvent = new SpellEnergyCollisionEvent();
    public SpellUnitCollisionEvent unitCollisionEvent = new SpellUnitCollisionEvent();

    #endregion

    #region Public helpers & tools

    /// <summary>
    /// Returns if the manifestation is currently colliding with the object
    /// </summary>
    public bool IsColliding(GameObject obj)
    {
        return m_Collided.Contains(obj);
    }

    /// <summary>
    /// Returns if the manifestation is currently colliding with the component
    /// </summary>
    public bool IsColliding<T>(T component) where T : MonoBehaviour
    {
        return IsColliding(component.gameObject);
    }

    /// <summary>
    /// Returns if the manifestation or any child of it is currently colliding with the object
    /// </summary>
    public bool IsCollidingRecursive(GameObject obj)
    {
        if (IsColliding(obj))
        {
            return true;
        }

        foreach (var child in holder.ownedEnergies)
        {
            var childManifestation = child.GetComponent<EnergyManifestation>();
            if (childManifestation != null && childManifestation.IsCollidingRecursive(obj))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Returns if the manifestation or any child of it is currently colliding with the component
    /// </summary>
    public bool IsCollidingRecursive<T>(T component) where T : MonoBehaviour
    {
        return IsCollidingRecursive(component.gameObject);
    }

    #endregion

    #region Collision handling helpers

    private int Collision_GetEnergy()
    {
        return m_previousEnergy;
    }

    private float Collision_GetCurrentVolume()
    {
        return currentVolume;
    }

    private float Collision_GetDensity()
    {
        return density;
    }

    private float Collision_GetMass()
    {
        return rigidBody.mass;
    }

    private float Collision_EstimateIntersectionVolume(Collider otherCollider, Vector3 relativeVelocity)
    {
        //If the other collider is big enough intersecting volume is estimated by simulating a AABB (with the same volume) colliding with AA wall (at the same speed)
        //Otherwise it's the other way around

        float otherVolumeEstimate;
        var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();
        if (otherManifestation != null)
        {
            otherVolumeEstimate = otherManifestation.Collision_GetCurrentVolume();
        }
        else
        {
            var colliderSize = otherCollider.bounds.size;
            otherVolumeEstimate = colliderSize.x * colliderSize.y * colliderSize.z;
        }

        var myCurrentVolume = Collision_GetCurrentVolume();
        var smallerVolume = Mathf.Min(myCurrentVolume, otherVolumeEstimate);
        var intersectingSurface = Mathf.Pow(smallerVolume, 2.0f / 3.0f);
        return Mathf.Clamp(intersectingSurface * relativeVelocity.magnitude * Time.fixedDeltaTime, 0.0f, myCurrentVolume);
    }

    private int Collision_EstimeIntersectionEnergy(Collider otherCollider, Vector3 relativeVelocity)
    {
        var intersectingVolume = Collision_EstimateIntersectionVolume(otherCollider, relativeVelocity);
        var intersectingMass = intersectingVolume * Collision_GetDensity();
        if (float.IsNaN(intersectingMass) || float.IsInfinity(intersectingMass))
        {
            return 0;
        }
        else
        {
            return (int)((intersectingMass * Energy.Scalef) / (EnergyPhysics.MassPerUnit(element) * lorentzFactor));
        }
    }

    #endregion

    #region Collision handling

    //Notes on collision handling:
    //All properties like: charge, volume, mass, density, temperature, ...
    //must be accessed through special functions because handling order is not deterministic
    //See region 'Collision handling helpers'

    private Vector3 Collision_CalculateNewVelocity(Rigidbody otherBody)
    {
        return (rigidBody.velocity * (rigidBody.mass - otherBody.mass) + (2 * otherBody.mass * otherBody.velocity)) / (rigidBody.mass + otherBody.mass);
    }

    private void HandleCollisionEnter(Collider otherCollider, Vector3 relativeVelocity)
    {
        //Note: See https://answers.unity.com/questions/696068/difference-between-forcemodeforceaccelerationimpul.html

        //Add to collided list & emit events
        m_Collided.Add(otherCollider.gameObject);
        SendMessage("OnObjectEnterCollision", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
        objectCollisionEvent.Invoke(this, otherCollider.gameObject, CollisionEventType.Enter);

        //Check smashing conditions
        var otherBody = otherCollider.GetComponent<Rigidbody>();
        if (!m_Collider.isTrigger && !otherCollider.isTrigger && otherBody != null)
        {
            var newVelocity = Collision_CalculateNewVelocity(otherBody);
            var impulseReceived = rigidBody.mass * (newVelocity - rigidBody.velocity);
            var smashImpulse = EnergyPhysics.SmashImpulse(element) * rigidBody.mass;
            if (impulseReceived.sqrMagnitude > smashImpulse * smashImpulse)
            {
                Smash();
                return;
            }
        }

        var otherUnit = otherCollider.GetComponent<Unit>();
        var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();
        if (otherUnit != null)
        {
            SendMessage("OnUnitEnterCollision", otherUnit, SendMessageOptions.DontRequireReceiver);
            unitCollisionEvent.Invoke(this, otherUnit, CollisionEventType.Enter);
            CollideWithUnit(otherUnit, relativeVelocity);
        }
        else if (otherManifestation != null)
        {
            SendMessage("OnEnergyEnterCollision", otherManifestation, SendMessageOptions.DontRequireReceiver);
            energyCollisionEvent.Invoke(this, otherManifestation, CollisionEventType.Enter);
            CollideWithManifestation(otherManifestation, relativeVelocity);
        }
        else if (!otherCollider.isTrigger)
        {
            if (otherBody != null)
            {
                CollideWithSolidBody(otherBody, relativeVelocity);
            }
            else
            {
                CollideWithStatic(otherCollider, relativeVelocity);
            }
        }
    }

    private void HandleCollisionStay(Collider otherCollider, Vector3 relativeVelocity)
    {
        var otherUnit = otherCollider.GetComponent<Unit>();
        var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();
        if (otherUnit != null)
        {
            CollideWithUnit(otherUnit, relativeVelocity);
        }
        else if (otherManifestation != null)
        {
            CollideWithManifestation(otherManifestation, relativeVelocity);
        }
        else if (!otherCollider.isTrigger)
        {
            var otherBody = otherCollider.GetComponent<Rigidbody>();
            if (otherBody != null)
            {
                CollideWithSolidBody(otherBody, relativeVelocity);
            }
            else
            {
                CollideWithStatic(otherCollider, relativeVelocity);
            }
        }
    }

    private void HandleCollisionExit(Collider otherCollider, Vector3 relativeVelocity)
    {
        //Remove from collided lists & emit events
        m_Collided.Remove(otherCollider.gameObject);
        SendMessage("OnObjectExitCollision", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
        objectCollisionEvent.Invoke(this, otherCollider.gameObject, CollisionEventType.Exit);

        var otherUnit = otherCollider.GetComponent<Unit>();
        var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();

        if (otherUnit != null)
        {
            SendMessage("OnUnitExitCollision", otherUnit, SendMessageOptions.DontRequireReceiver);
            unitCollisionEvent.Invoke(this, otherUnit, CollisionEventType.Exit);
        }
        else if (otherManifestation != null)
        {
            SendMessage("OnEnergyExitCollision", otherManifestation, SendMessageOptions.DontRequireReceiver);
            energyCollisionEvent.Invoke(this, otherManifestation, CollisionEventType.Exit);
        }
    }

    private void Collision_ApplyElementalEffectToUnit(Unit other)
    {

    }

    private void CollideWithUnit(Unit other, Vector3 relativeVelocity)
    {
        var myOwnerUnit = holder.ResolveOwner().GetComponent<Unit>();
        if (myOwnerUnit != null && !myOwnerUnit.CanAttack(other))
        {
            //Cannot attack unit
            return;
        }

        Collision_ApplyElementalEffectToUnit(other);

        var passThrough = m_Collider.isTrigger;
        if (!passThrough)
        {
            //If I am solid - nothing happens
            return;
        }

        //Unfriendly unit - lose volume
        var energyLost = Collision_EstimeIntersectionEnergy(other.GetComponent<Collider>(), relativeVelocity);
        DecreaseEnergy(energyLost);
    }

    private void CollideWithManifestation(EnergyManifestation other, Vector3 relativeVelocity)
    {
        var myOwner = holder.ResolveOwner();
        var otherOwner = other.holder.ResolveOwner();
        if (myOwner == otherOwner)
        {
            //Same owner - cannot attack
            return;
        }

        var myOwnerUnit = myOwner.GetComponent<Unit>();
        if (myOwnerUnit != null)
        {
            var otherOwnerUnit = otherOwner.GetComponent<Unit>();
            if (!myOwnerUnit.CanAttack(otherOwnerUnit))
            {
                //Cannot attack other
                return;
            }
        }

        //Destructive interaction
        var passThrough = m_Collider.isTrigger;
        var otherPassThrough = other.m_Collider.isTrigger;
        
        if (passThrough)
        {
            //I am pass through - lose energy
            var energyLost = Collision_EstimeIntersectionEnergy(other.GetComponent<Collider>(), relativeVelocity);
            DecreaseEnergy(energyLost);
        }
        else if (otherPassThrough) //&& !passThrough)
        {
            //I am solid & other is pass though - apply force by the interaction
            var newVelocity = Collision_CalculateNewVelocity(other.rigidBody);
            var impulseReceived = rigidBody.mass * (newVelocity - rigidBody.velocity);
            var smashImpulse = EnergyPhysics.SmashImpulse(element) * rigidBody.mass;
            if (impulseReceived.sqrMagnitude > smashImpulse * smashImpulse)
            {
                Smash();
            }
            else
            {
                ApplyForce(impulseReceived, ForceMode.Impulse);
            }
        }
    }
    
    private void CollideWithSolidBody(Rigidbody other, Vector3 relativeVelocity)
    {
        CollideWithStatic(other.GetComponent<Collider>(), relativeVelocity);
    }

    private void CollideWithStatic(Collider otherCollider, Vector3 relativeVelocity)
    {
        //Destructive interaction with random solid
        //If I am solid:
        //1) smashing is handled in calling fn.
        //2) collision is resolved by the physics engine
        //If I am pass-through:
        //Calculate volume lost & lose that energy instantly

        var passThrough = m_Collider.isTrigger;
        if (!passThrough)
        {
            return;
        }

        var energyLost = Collision_EstimeIntersectionEnergy(otherCollider, relativeVelocity);
        DecreaseEnergy(energyLost);
    }

    #endregion

    #region Collision handling OLD

    /// <summary>
    /// Called on collision enter
    /// </summary>
    private void HandleCollisionEnter_OLD(Collider otherCollider)
    {
        m_Collided.Add(otherCollider.gameObject);
        SendMessage("OnObjectEnterCollision", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
        objectCollisionEvent.Invoke(this, otherCollider.gameObject, CollisionEventType.Enter);

        var otherBody = otherCollider.GetComponent<Rigidbody>();
        if (otherBody != null)
        {
            //Other object has a rigid body

            var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();
            if (otherManifestation == null)
            {
                //Not an energy manifestation (not a spell)

                var otherUnit = otherCollider.GetComponent<Unit>();
                if (otherUnit != null)
                {
                    //Handle collision event with unit
                    SendMessage("OnUnitEnterCollision", otherUnit, SendMessageOptions.DontRequireReceiver);
                    unitCollisionEvent.Invoke(this, otherUnit, CollisionEventType.Enter);
                    
                    //Hit unit - check if friendly or not
                    var myOwner = holder.ResolveOwner();
                    if (otherUnit.CanAttack(myOwner.GetComponent<Unit>()))
                    {
                        //Hit unfriendly unit - try dealing damage
                        if (m_Collider.isTrigger)
                        {
                            //I am a 'transparent' manifestation (raw/mana/fire/...) - deal damage instantly
                            var dmg = GetDamage();
                            otherUnit.DealDamage(dmg); //TODO maybe move in Unit, so it can take damage from other objs
                            SendMessage("OnHit", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
                            Util.Destroy(gameObject, "unfriendy unit"); //Destroy self in the process
                        }
                        else
                        {
                            //I am a 'solid' manifestation (earth/ice/...) - deal damage if enough velocity
                            //var damageVelocity = EnergyPhysics.DamageVelocity(element);
                            var sqVelocity = rigidBody.velocity.sqrMagnitude;
                            //if (sqVelocity > damageVelocity * damageVelocity)
                            //{
                                //Deal damage only if moving fast enough
                                var dmg = GetDamage();
                                otherUnit.DealDamage(dmg); //TODO maybe move in Unit, so it can take damage from other fast moving objs
                                SendMessage("OnHit", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
                                var smashVelocity = EnergyPhysics.SmashImpulse(element);
                                if (m_Collider.isTrigger || sqVelocity > smashVelocity * smashVelocity)
                                {
                                    //Destroy (smash) self only if moving fast enough
                                    Smash();
                                }
                            //}
                        }
                        return;
                    }
                    else
                    {
                        //Hit friendly unit - ignore
                        return;
                    }
                }
                else
                {
                    //Didn't hit a unit (probably a decoration of some sort) - try smashing self
                    var smashVelocity = EnergyPhysics.SmashImpulse(element);
                    var sqVelocity = rigidBody.velocity.sqrMagnitude;
                    if (m_Collider.isTrigger || sqVelocity > smashVelocity * smashVelocity)
                    {
                        //Destroy (smash) self only if moving fast enough
                        Smash();
                    }
                }
            }
            else
            {
                SendMessage("OnEnergyEnterCollision", otherManifestation, SendMessageOptions.DontRequireReceiver);
                energyCollisionEvent.Invoke(this, otherManifestation, CollisionEventType.Enter);

                //The other object has a manifestation (is a spell)
                var myOwner = holder.ResolveOwner();
                var otherOwner = otherManifestation.holder.ResolveOwner();
                if (myOwner != otherOwner)
                {
                    //Hit unfriendly manifestation - TODO implement proper interaction
                    if (element != Energy.Element.Raw && otherManifestation.element != Energy.Element.Raw)
                    {
                        Util.Destroy(gameObject, "unfriendly manif");
                    }
                }
            }
        }
        else
        {
            //If static object (no Rigidbody)
            //Note: cannot be EnergyManifestation (they require a Rigidbody)

            //If colliding with a trigger - it must be irrelevant
            if (otherCollider.isTrigger)
            {
                return;
            }

            //Try smashing self into static object - TODO fix this check
            var smashVelocity = EnergyPhysics.SmashImpulse(element);
            var sqVelocity = rigidBody.velocity.sqrMagnitude;
            if (m_Collider.isTrigger || sqVelocity > smashVelocity * smashVelocity)
            {
                //Destroy (smash) self only if moving fast enough
                Smash();
            }
        }
    }

    /// <summary>
    /// Called on collision exit
    /// </summary>
    /// <param name="otherCollider"></param>
    private void HandleCollisionExit_OLD(Collider otherCollider)
    {
        m_Collided.Remove(otherCollider.gameObject);
        SendMessage("OnObjectExitCollision", otherCollider.gameObject, SendMessageOptions.DontRequireReceiver);
        objectCollisionEvent.Invoke(this, otherCollider.gameObject, CollisionEventType.Exit);

        //Handle collision event with unit
        var otherUnit = otherCollider.GetComponent<Unit>();
        if (otherUnit != null)
        {
            SendMessage("OnUnitExitCollision", otherUnit, SendMessageOptions.DontRequireReceiver);
            unitCollisionEvent.Invoke(this, otherUnit, CollisionEventType.Exit);
        }
        else
        {
            //Else - try handling collision with another energy manif.
            var otherManifestation = otherCollider.GetComponent<EnergyManifestation>();
            if (otherManifestation != null)
            {
                SendMessage("OnEnergyExitCollision", otherManifestation, SendMessageOptions.DontRequireReceiver);
                energyCollisionEvent.Invoke(this, otherManifestation, CollisionEventType.Exit);

                var myOwner = holder.ResolveOwner();
                var otherOwner = otherManifestation.holder.ResolveOwner();
                if (myOwner != otherOwner)
                {
                    //Exit collision with unfriendly manifestation - TODO implement proper interaction
                    Util.Destroy(gameObject, "unfriendly manif");
                }
            }
        }
    }
    
    #endregion

    #region Unity interface
    
    private Vector3 Collision_CalculateRelativeVelocity(Collider otherCollider)
    {
        var otherBody = otherCollider.GetComponent<Rigidbody>();
        if (otherBody == null)
        {
            return rigidBody.velocity;
        }

        return rigidBody.velocity - otherBody.velocity;
    }

    private void OnTriggerEnter(Collider other) { HandleCollisionEnter(other, Collision_CalculateRelativeVelocity(other)); }
    private void OnTriggerStay(Collider other) { HandleCollisionStay(other, Collision_CalculateRelativeVelocity(other)); }
    private void OnTriggerExit(Collider other) { HandleCollisionExit(other, Collision_CalculateRelativeVelocity(other)); }
    private void OnCollisionEnter(Collision collision) { HandleCollisionEnter(collision.collider, collision.relativeVelocity); }
    private void OnCollisionStay(Collision collision) { HandleCollisionEnter(collision.collider, collision.relativeVelocity); }
    private void OnCollisionExit(Collision collision) { HandleCollisionExit(collision.collider, collision.relativeVelocity); }

    /// <summary>
    /// Energy at end of previous frame
    /// </summary>
    private int m_previousEnergy = 0;

    private void Collision_LateUpdate(float dt)
    {
        m_previousEnergy = GetEnergy();
    }

    #endregion
}
