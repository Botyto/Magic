﻿using UnityEngine;

public partial class EnergyManifestation
{
    #region Internals

    /// <summary>
    /// If visuals have been marked as dirty (energy/element/shape/temperature has changed)
    /// </summary>
    private bool m_VisualsDirty = false;

    /// <summary>
    /// Marks visuals as dirty (will be update at end of frame - next LateUpdate)
    /// </summary>
    private void SetVisualsDirty()
    {
        m_VisualsDirty = true;
    }

    /// <summary>
    /// Update manifestation visualization (only visual parts)
    /// </summary>
    private void UpdateRenderingSettings()
    {
        GetComponent<MeshFilter>().sharedMesh = EnergyVisuals.FindMesh(shape);
        GetComponent<MeshRenderer>().sharedMaterial = EnergyVisuals.FindMaterial(element);
    }

    /// <summary>
    /// Updates manifestation visualization (both phyisical and visual parts)
    /// </summary>
    private void UpdateVisuals()
    {
        m_VisualsDirty = false;

        //Optimize
        UpdateCollider();
        UpdatePhysicalProperties();
        UpdateRenderingSettings();
        UpdateParticles();
    }

    /// <summary>
    /// Update collider according to shape & element
    /// </summary>
    private void UpdateCollider()
    {
        switch (shape)
        {
            case Energy.Shape.Sphere:
                if (m_Collider is SphereCollider) break; //Already has correct collider
                if (m_Collider != null) Util.Destroy(m_Collider); //Destroy incorrect collider

                { //Attach & setup correct collider
                    var sphere = gameObject.AddComponent<SphereCollider>();
                    sphere.radius = 0.62035f; //sphere with volume 1 cubic meter
                    m_Collider = sphere;
                }
                break;
            case Energy.Shape.Cube:
                if (m_Collider is BoxCollider) break; //Already has correct collider
                if (m_Collider != null) Util.Destroy(m_Collider); //Destroy incorrect collider

                { //Attach & setup correct collider
                    var box = gameObject.AddComponent<BoxCollider>();
                    box.size = Vector3.one;
                    m_Collider = box;
                }
                break;

            case Energy.Shape.Capsule:
                if (m_Collider is CapsuleCollider) break; //Already has correct collider
                if (m_Collider != null) Util.Destroy(m_Collider);

                { //Attach & setup correct collider
                    var capsule = gameObject.AddComponent<CapsuleCollider>();
                    capsule.radius = 0.45708f;
                    capsule.height = 2 * capsule.radius;
                    m_Collider = capsule;
                }
                break;

            default:
                if (m_Collider is MeshCollider)
                {
                    //Already has correct collider
                    (m_Collider as MeshCollider).sharedMesh = EnergyVisuals.FindCollider(shape);
                    break;
                }
                if (m_Collider != null) Util.Destroy(m_Collider); //Destroy incorrect collider

                { //Attach & setup correct collider
                    var meshc = gameObject.AddComponent<MeshCollider>();
                    meshc.sharedMesh = EnergyVisuals.FindCollider(shape);
                    meshc.convex = true;
                    m_Collider = meshc;
                }
                break;
        }

        m_Collider.isTrigger = EnergyPhysics.ColliderIsTrigger(element);
        rigidBody.useGravity = EnergyPhysics.BodyUsesGravity(element);
        rigidBody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic; //TODO decide if this is needed
    }

    #endregion

    #region Unity interface

    private void Visuals_Start()
    {
        UpdateVisuals();
    }

    private void Visuals_LateUpdate(float dt)
    {
        if (m_VisualsDirty)
        {
            UpdateVisuals();
        }
    }

    #endregion
}
