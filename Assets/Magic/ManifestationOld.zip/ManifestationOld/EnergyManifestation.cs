﻿using UnityEngine;

/// <summary>
/// A physically manifested energy
/// </summary>
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public partial class EnergyManifestation : EnergyUser
{
    #region Unity interface
    
    protected void Start()
    {
        Visuals_Start();
    }

    private void LateUpdate()
    {
        Charge_LateUpdate(Time.fixedDeltaTime);
        Physics_LateUpdate(Time.fixedDeltaTime);
        Collision_LateUpdate(Time.fixedDeltaTime);

        Visuals_LateUpdate(Time.fixedDeltaTime);
    }

    #endregion
}
