﻿using System;
using UnityEngine;

public partial class EnergyManifestation
{
    #region Members

    public GameObject particles;

    #endregion

    #region Public particle triggers

    /// <summary>
    /// Triggers particles for when smashing
    /// </summary>
    private void TriggerSmashParticles()
    {
        ChangeParticlePrefab(EnergyParticles.SmashParticles, false);
    }

    /// <summary>
    /// Triggers particles for when disposing
    /// </summary>
    private void TriggerDisposeParticles()
    {
        ChangeParticlePrefab(EnergyParticles.SmashParticles, false);
    }

    /// <summary>
    /// Update manifestation visualization (attached particles only)
    /// </summary>
    private void UpdateParticles()
    {
        var newParticlesCreated = ChangeParticlePrefab(EnergyParticles.IdleParticles, true);
        if (!newParticlesCreated)
        {
            //New particles would have already had they shapes set
            UpdateParticlesShapes();
        }
    }

    #endregion

    #region Particle lifetime management

    private void ClearParticles()
    {
        if (particles != null)
        {
            Util.Destroy(particles);
            particles = null;
        }
    }

    private void UpdateParticlesShapes()
    {
        if (particles == null)
        {
            return;
        }

        //Set up all particle systems' shapes
        var particleSystems = particles.GetComponentsInChildren<ParticleSystem>();
        foreach (var ps in particleSystems)
        {
            var shapeObj = ps.shape;
            if (shapeObj.enabled)
            {
                shapeObj.shapeType = EnergyParticles.ResolveEmitterShape(shape);
                shapeObj.scale = transform.localScale;
            }
        }
    }

    private void CreateParticles(GameObject prefab, bool attach = true)
    {
        //Instanciate prefab
        if (attach)
        {
            particles = Instantiate(prefab, transform);
        }
        else
        {
            particles = Instantiate(prefab, transform.position, transform.rotation);
            particles.transform.localScale = transform.localScale;
        }

        particles.name = prefab.name;

        UpdateParticlesShapes();
    }

    private bool ChangeParticlePrefab(Func<Energy.Element, GameObject> fn, bool attach = true)
    {
        var prefab = fn(element);

        //No prefab found (element doesn't have such particles)
        if (prefab == null)
        {
            ClearParticles();
            return false;
        }

        //We have particles already
        if (particles != null)
        {
            //Check if they need to be changed
            if (prefab.name != particles.name)
            {
                ClearParticles();
                CreateParticles(prefab, attach);
                return true;
            }
        }
        else //We don't have particles
        {
            CreateParticles(prefab, attach);
            return true;
        }

        return false;
    }

    #endregion
}
