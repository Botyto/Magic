﻿using UnityEngine;

/// <summary>
/// A physically manifested energy
/// </summary>
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public partial class EnergyManifestation
{
    #region Members

    /// <summary>
    /// Manifestation element
    /// </summary>
    public Energy.Element element = Energy.DefaultElement;
    
    /// <summary>
    /// Manifestation shape
    /// </summary>
    public Energy.Shape shape = Energy.DefaultShape;

    /// <summary>
    /// Manifestation temperature (°C)
    /// </summary>
    public int temperature;

    /// <summary>
    /// Element to which to switch at end of this frame (next LateUpdate)
    /// </summary>
    private Energy.Element m_NextElement = Energy.DefaultElement;

    /// <summary>
    /// Shape to which to switch at end of this frame (next LateUpdate)
    /// </summary>
    private Energy.Shape m_NextShape = Energy.DefaultShape;

    #endregion
    
    #region Public helpers & tools

    /// <summary>
    /// Calculate damage this manifestation can deal at this moment
    /// </summary>
    public int GetDamage()
    {
        return (int)(Energy.DamagePerUnit(element) * GetEnergyScaledf());
    }

    #endregion

    #region Internals
    
    /// <summary>
    /// Callback for when energy held has changed
    /// </summary>
    private void EnergyChanged(int delta)
    {
        SetVisualsDirty();
    }

    /// <summary>
    /// Callback for when energy held has been depleted
    /// </summary>
    private void EnergyDepleted()
    {
        Util.Destroy(gameObject, "energy depleted");
    }

    /// <summary>
    /// Calculate the temperature of a element with given volume change
    /// </summary>
    private static int CalculateTemperature(Energy.Element element, float relativeVolume)
    {
        // ((0K + norm) * (k / Vr)) - 0K
        return (int)((Energy.MinTemperature + Energy.NormalTemperature(element)) * (Energy.TemperatureConstant(element) / relativeVolume) - Energy.MinTemperature);
    }

    private void Charge_LateUpdate(float dt)
    {
        //Energies without an owner lose charge over time
        if (holder.owner == null)
        {
            DecreaseEnergy(Mathf.Min(100, GetEnergy() / 6000));
        }

        //TODO check if temperature is ok
        temperature = CalculateTemperature(element, currentVolume / originalVolume);

        //Late change the element
        if (m_NextElement != element)
        {
            ChangeElementNow(m_NextElement);
            m_NextElement = element;
        }

        //Late change the shape
        if (m_NextShape != shape)
        {
            ChangeShapeNow(m_NextShape);
            m_NextShape = shape;
        }
    }
    
    #endregion
}
