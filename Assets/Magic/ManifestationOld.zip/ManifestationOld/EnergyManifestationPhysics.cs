﻿using UnityEngine;

public partial class EnergyManifestation
{
    #region Settings

    public const float MinDeformVolume = 0.000001f;

    private const float DeformationTolerance = 0.01f;

    #endregion

    #region Members

    /// <summary>
    /// Manifestation original volume (depends on element and energy held)
    /// This is the volume that would be reached if no deformation is applied.
    /// See currentVolume, for volume that takes into account the deformation.
    /// </summary>
    public float originalVolume;

    /// <summary>
    /// Manifestation current volume (depends on element, energy held and deformation)
    /// See originalVolume, for volume that would be reached if no deformation is applied.
    /// </summary>
    public float currentVolume { get { return originalVolume * deformation.x * deformation.y * deformation.z; } }

    /// <summary>
    /// Manifestation current density
    /// </summary>
    public float density { get { return rigidBody.mass / currentVolume; } }

    /// <summary>
    /// Phyisical deformation
    /// Note: Never write here from outside!
    /// </summary>
    public Vector3 deformation = Vector3.one;
    
    /// <summary>
    /// Rigidbody component
    /// </summary>
    public Rigidbody rigidBody { get { return GetComponent<Rigidbody>(); } }

    /// <summary>
    /// Lorentz factor for calculating the relativistic mass of this manifestation
    /// </summary>
    public float lorentzFactor
    {
        get
        {
            //https://en.wikipedia.org/wiki/Lorentz_factor
            var sqrSpeed = rigidBody.velocity.sqrMagnitude;
            return 1.0f / Mathf.Sqrt(1 - sqrSpeed / Energy.SqrSpeedLimit);
        }
    }

    #endregion

    #region Internals

    /// <summary>
    /// Update manifestation visualization (only physical parts)
    /// </summary>
    private void UpdatePhysicalProperties()
    {
        originalVolume = EnergyPhysics.BaseVolume(element) + EnergyPhysics.VolumePerUnit(element) * GetEnergyScaledf();
        transform.localScale = deformation * Mathf.Pow(originalVolume, 1.0f / 3.0f);
    }

    /// <summary>
    /// This is where the Deform() manipulation will store all of it's input
    /// </summary>
    private Vector3 m_DeformationAccumulator = Vector3.zero;

    private void Physics_LateUpdate(float dt)
    {
        //TODO decide if this should stay here or in EnergyManifestationManipulation.cs
        //If there's need to return back to shape
        //if (deformationAccumulator != Vector3.zero ||
        //    Mathf.Abs(deformation.x - 1) > DeformationTolerance ||
        //    Mathf.Abs(deformation.y - 1) > DeformationTolerance ||
        //    Mathf.Abs(deformation.z - 1) > DeformationTolerance)
        //{
        //    var newDeformation = SolveResultingDeformation(deformationAccumulator);
        //    transform.localScale = transform.localScale.MulDiv(newDeformation, deformation);
        //    deformation = newDeformation;
        //    deformationAccumulator = Vector3.zero;
        //}

        //TODO implement rotation locking (to velocity)
        if (rigidBody.velocity != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(rigidBody.velocity, Vector3.up);
        }
        
        rigidBody.mass = EnergyPhysics.MassPerUnit(element) * GetEnergyScaledf() * lorentzFactor;
    }

    private Vector3 SolveResultingDeformation(Vector3 stress)
    {
        var elasticity_coef = Energy.ElementElasticity(element);
        return new Vector3(
            SolveResultingDeformation(elasticity_coef, stress.x),
            SolveResultingDeformation(elasticity_coef, stress.y),
            SolveResultingDeformation(elasticity_coef, stress.z));
    }

    private float SolveResultingDeformation(float k, float stress)
    {
        //stress == 0 - no stress
        if (stress == 0.0f)
        {
            return 1.0f;
        }
        //stress > 0 means compressive
        else if (stress > 0.0f)
        {
            //stress = k/deformation - k
            //s = k/d - k
            //d = k / (s + k)
            return k / (stress + k);
        }
        //stress < 0 means tensile
        else if (stress < 0.0f)
        {
            //stress = k*exp((deformation - 1) * 1.5) - k
            //s = k*exp((d - 1) * 1.5) - k
            //d = 2/3 * logn(s/k + 1) + 1
            return (2.0f / 3.0f) * Mathf.Log(-stress / k + 1) + 1;
        }

        //Will never reach here :)
        return 1.0f;
    }

    #endregion
}